package com.midtree.hospitaldetails.exception;

public class DoctorNotFoundException  extends RuntimeException{

    public DoctorNotFoundException(String string) {
        super();
    }
}
