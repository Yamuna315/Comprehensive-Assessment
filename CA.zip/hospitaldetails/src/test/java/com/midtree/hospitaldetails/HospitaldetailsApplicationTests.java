package com.midtree.hospitaldetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitaldetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
